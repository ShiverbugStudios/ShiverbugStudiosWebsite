Shiverbug Studios Ltd
https://shiverbugstudios.com

Press contact: contact@shiverbugstudios.com

Everything in this archive is free to use in coverage of Shiverbug Studios and
Out of Water. Please don't alter the logo. Screenshots are work in
progress and can be credited to Shiverbug Studios.

Fact sheet, descriptions and the latest of all of this: https://shiverbugstudios.com/press
